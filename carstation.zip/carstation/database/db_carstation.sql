-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2020 at 04:47 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_carstation`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pickup` varchar(255) NOT NULL,
  `drop_off` varchar(255) NOT NULL,
  `car_id` int(255) NOT NULL,
  `pickup_time` varchar(255) NOT NULL,
  `drop_off_time` varchar(255) NOT NULL,
  `pickup_date` date NOT NULL,
  `drop_off_date` date NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`id`, `user_id`, `pickup`, `drop_off`, `car_id`, `pickup_time`, `drop_off_time`, `pickup_date`, `drop_off_date`, `status`) VALUES
(1, 2, 'Dhaka', 'Sylhet', 1, '0', '0', '2020-12-04', '2020-12-05', ''),
(2, 2, 'Dhaka', 'Sylhet', 2, '1 : 35 PM', '7 : 00 PM', '2020-12-04', '2020-12-04', ''),
(3, 2, 'Dhaka', 'Sylhet', 3, '1 : 35 PM', '7 : 35 PM', '2020-12-04', '2020-12-05', ''),
(4, 2, 'Dhaka', 'Sylhet', 1, '1 : 35 PM', '2 : 35 PM', '2020-12-03', '2020-12-03', ''),
(5, 4, 'Sylhet', 'Dhaka', 3, '1 : 30 PM', '7 : 30 PM', '2020-12-04', '2020-12-05', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_car`
--

CREATE TABLE `tbl_car` (
  `id` int(11) NOT NULL,
  `car_name` varchar(255) NOT NULL,
  `car_photo` varchar(255) NOT NULL,
  `car_detail` varchar(255) NOT NULL,
  `car_rent` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_car`
--

INSERT INTO `tbl_car` (`id`, `car_name`, `car_photo`, `car_detail`, `car_rent`) VALUES
(1, 'pajero rang', '44.jpg', 'Aliquam sollicitudin dolores tristiquvel ornare, vitae aenean.', '20'),
(2, 'mirage range', '51.jpg', 'Aliquam sollicitudin dolores tristiquvel ornare, vitae aenean.', '30'),
(3, 'Rools royce', '71.jpg', 'Aliquam sollicitudin dolores tristiquvel ornare, vitae aenean.', '30'),
(4, 'Volkswagen', '61.jpg', 'USA collected new vehicles', '25'),
(5, 'Porshay', 'v3.jpg', 'This is the latest car in the modern time', '55'),
(6, 'Toyota', '8.jpg', 'This is a modern car which has new facility', '35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_message`
--

INSERT INTO `tbl_message` (`id`, `name`, `email`, `message`) VALUES
(1, 'Jafor', 'jafor@gmail.com', 'I want to know about your website'),
(2, 'Ahmed', 'ahmed@gmail.com', 'This is nice site');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `post_name` varchar(255) NOT NULL,
  `post_date` text NOT NULL,
  `post_detail` text NOT NULL,
  `post_photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `post_name`, `post_date`, `post_detail`, `post_photo`) VALUES
(5, 'Bumper Offer For Summer', '1607277600', '500 tk per hour in city area and local stations.', '74.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `type`) VALUES
(1, 'Admin', 'admin@gmail.com', '123', 'admin'),
(2, 'Jafor', 'jafor@gmail.com', '123', 'user'),
(3, 'Ahmed', 'ahmed@gmail.com', '123', 'user'),
(4, 'Chowdhury', 'chowdhury@gmail.com', '123', 'user'),
(5, 'Hussain Ahmed', 'hussain@gmail.com', '222', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_car`
--
ALTER TABLE `tbl_car`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_car`
--
ALTER TABLE `tbl_car`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
