<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {

        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if($this->session->userdata('type')!='admin'){
			redirect('welcome');
		}else{
		
		}


    }
	
	public function index()
	{

		$data['booking']=$this->db->select('*,tbl_booking.id as b_id')->from('tbl_booking,tbl_user,tbl_car')->where('tbl_booking.user_id=tbl_user.id')->where('tbl_car.id=tbl_booking.car_id')->order_by('b_id','DESC')->limit('5')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		$this->load->view('admin/dashboard',$data);
		$this->load->view('admin/inc/footer');
	}


	public function Add_car()
	{
		 
		 $this->form_validation->set_rules('car_name', 'Car Name', 'required|regex_match[/^[a-zA-Z- ]*$/]');
		 $this->form_validation->set_rules('car_rent', 'Car Rent', 'required');
		 $this->form_validation->set_rules('car_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {
		 

			$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/add-car');
		 $this->load->view('admin/inc/footer');

		}else{

			$idata['car_name']=$this->input->post('car_name');
			$idata['car_rent']=$this->input->post('car_rent');
			$idata['car_detail']=$this->input->post('car_detail');
	
			 

				if(!empty($_FILES) && ($_FILES['car_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('car_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

	
				} else {
			 
				$avatar = $this->upload->data();
				$car_photo = $avatar['file_name'];

				$idata['car_photo']=$car_photo;

			 

				}

						 

			}else{
			
			$message='<div class="alert alert-danger">Please Add Your Image</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/add-car');

			}

			$this->db->insert('tbl_car',$idata);

			$message='<div class="alert alert-success">Car Added</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Add-car');

		}

		 

	}


	public function View_car()
	{
		$data['car']=$this->db->select('*')->from('tbl_car')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/view-car',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_car($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_car');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}




	public function Edit_car($id)
	{
		 
		 $this->form_validation->set_rules('car_name', 'Car Name', 'required|regex_match[/^[a-zA-Z- ]*$/]');
		 $this->form_validation->set_rules('car_rent', 'Car Rent', 'required');
		 $this->form_validation->set_rules('car_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {

		 $edata['car']=$this->db->where('id',$id)->get('tbl_car')->result_array();
		 

		 		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/edit-car',$edata);
		 $this->load->view('admin/inc/footer');

		}else{

				$idata['car_name']=$this->input->post('car_name');
			$idata['car_rent']=$this->input->post('car_rent');
			$idata['car_detail']=$this->input->post('car_detail');
	
			 
			
			if(!empty($_FILES) && ($_FILES['car_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('car_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

				redirect('Admin/Edit-car/'.$id);

				} else {
			

				$img_link=$this->db->where('id',$id)->get('tbl_car')->result_array()[0]['image'];
			
			

				 unlink('image/'.$img_link.'');


				$avatar = $this->upload->data();
				$car_photo = $avatar['file_name'];

				$idata['car_photo']=$car_photo;

			  

				}

						 

			}


			$this->db->where('id',$id)->update('tbl_car',$idata);

			$message='<div class="alert alert-success">Car Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Edit-car/'.$id);

		}

		 

	}


	public function View_message()
	{
		$data['message']=$this->db->select('*')->from('tbl_message')->order_by('id','DESC')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/view-message',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_message($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_message');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}


	public function View_booking()
	{
		$data['booking']=$this->db->select('*,tbl_booking.id as b_id')->from('tbl_booking,tbl_user,tbl_car')->where('tbl_booking.user_id=tbl_user.id')->where('tbl_car.id=tbl_booking.car_id')->order_by('b_id','DESC')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/view-booking',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_booking($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_booking');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}


	public function View_user()
	{
		$data['user']=$this->db->where('type','user')->get('tbl_user')->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/view-user',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_user($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_user');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}


	public function Add_post()
	{
		 
		 $this->form_validation->set_rules('post_name', 'post Name', 'required');
		 $this->form_validation->set_rules('post_date', 'post Date', 'required');
		 $this->form_validation->set_rules('post_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {
		 

			$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/add-post');
		 $this->load->view('admin/inc/footer');

		}else{

			$idata['post_name']=$this->input->post('post_name');
			$idata['post_date']=strtotime($this->input->post('post_date'));
			$idata['post_detail']=$this->input->post('post_detail');
	
			 

				if(!empty($_FILES) && ($_FILES['post_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('post_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

	
				} else {
			 
				$avatar = $this->upload->data();
				$post_photo = $avatar['file_name'];

				$idata['post_photo']=$post_photo;

			 

				}

						 

			}else{
			
			$message='<div class="alert alert-danger">Please Add Your Image</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/add-post');

			}

			$this->db->insert('tbl_post',$idata);

			$message='<div class="alert alert-success">Post Added</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Add-post');

		}

		 

	}


	public function View_post()
	{
		$data['post']=$this->db->select('*')->from('tbl_post')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/view-post',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_post($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_post');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}




	public function Edit_post($id)
	{
		 
		 $this->form_validation->set_rules('post_name', 'post Name', 'required');
		 $this->form_validation->set_rules('post_date', 'post Rent', 'required');
		 $this->form_validation->set_rules('post_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {

		 $edata['post']=$this->db->where('id',$id)->get('tbl_post')->result_array();
		 

		 		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar');
		$this->load->view('admin/inc/sidebar');
		 $this->load->view('admin/edit-post',$edata);
		 $this->load->view('admin/inc/footer');

		}else{

				$idata['post_name']=$this->input->post('post_name');
			$idata['post_date']=strtotime($this->input->post('post_date'));
			$idata['post_detail']=$this->input->post('post_detail');
	
			 
			
			if(!empty($_FILES) && ($_FILES['post_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('post_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

				redirect('Admin/Edit-post/'.$id);

				} else {
			

				$img_link=$this->db->where('id',$id)->get('tbl_post')->result_array()[0]['image'];
			
			

				 unlink('image/'.$img_link.'');


				$avatar = $this->upload->data();
				$post_photo = $avatar['file_name'];

				$idata['post_photo']=$post_photo;

			  

				}

						 

			}


			$this->db->where('id',$id)->update('tbl_post',$idata);

			$message='<div class="alert alert-success">Post Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Edit-post/'.$id);

		}

		 

	}




}
