<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		$this->form_validation->set_rules('password', 'Password', 'required');


		if ($this->form_validation->run() == FALSE)
		{
		
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('admin/login');
		$this->load->view('inc/footer');

		}else{

				$data['email']=$this->input->post('email');
				$data['password']=$this->input->post('password');
				
				
				$this->db->where('email',$data['email']);
				$this->db->where('password',$data['password']);
				$result = $this->db->get('tbl_user')->result_array();
				
				if($result){
				
 
				
				$s_data['type']=$result[0]['type'];
				$s_data['email']=$result[0]['email'];
				$s_data['id']=$result[0]['id'];
				$s_data['name']=$result[0]['name'];
				 
				$this->session->set_userdata($s_data);

				if($s_data['type']=='admin'){

					redirect('Admin');


				}else{

					redirect('User');

				}
					
				 
				
				 
				}else{
					
				
				$msg='<div class="alert alert-danger">Invalid Credential. Please Try Again </div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect('login');

					
				}
		}
	}
}
