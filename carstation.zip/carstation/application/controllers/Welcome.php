<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{

		$data['all_carlist']=$this->db->get('tbl_car')->result_array();
		
		$this->form_validation->set_rules('car_id', 'Car Name', 'required');
		$this->form_validation->set_rules('pickup', 'Pick Up', 'required');
		$this->form_validation->set_rules('drop_off', 'Drop Off', 'required');
		$this->form_validation->set_rules('pickup_date', 'Pick Up', 'required');
		$this->form_validation->set_rules('drop_off_date', 'Drop Off', 'required');
		$this->form_validation->set_rules('pickup_time', 'Pick Up Time', 'required');
		$this->form_validation->set_rules('drop_off_time', 'Drop Off Time', 'required');

		 if ($this->form_validation->run() == FALSE)
		 {

		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('home',$data);
		$this->load->view('inc/footer');

		}else{

		if(!$this->session->userdata('id'))
		{	

			if($this->session->userdata('type')!='user')
			{
				$message='<div class="alert alert-warning">Please Login</div>';

				$this->session->set_flashdata('message',$message);

				redirect('Welcome');	
			}	


			$message='<div class="alert alert-warning">Please Login</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Welcome');	 
		}


		$idata['car_id']=$this->input->post('car_id');
		$idata['pickup']=$this->input->post('pickup');
		$idata['drop_off']=$this->input->post('drop_off');
		$idata['pickup_date']=date('Y-m-d',strtotime($this->input->post('pickup_date')));
		$idata['drop_off_date']=date('Y-m-d',strtotime($this->input->post('drop_off_date')));
		$idata['pickup_time']=$this->input->post('pickup_time');
		$idata['drop_off_time']=$this->input->post('drop_off_time');
		$idata['user_id']=$this->session->userdata('id');;

		$this->db->insert('tbl_booking',$idata);

		$message='<div class="alert alert-success">Booking Added</div>';

		$this->session->set_flashdata('message',$message);

		redirect('Welcome');	 



		}
	}


	 
}
