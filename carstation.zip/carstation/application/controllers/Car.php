<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class car extends CI_Controller {

	
	public function index()
	{

		$data['all_carlist']=$this->db->get('tbl_car')->result_array();
			
		$this->load->library('pagination');

		if($this->input->post('car_name')){

			$query= $this->db->where('id',$this->input->post('car_name'));
		}

		if($this->input->post('car_search')){

			$query= $this->db->where('car_name',$this->input->post('car_search'));
			$query= $this->db->or_where('car_rent',$this->input->post('car_search'));
			$query= $this->db->or_where('car_detail',$this->input->post('car_search'));
		}

		$query= $this->db->get('tbl_car');

		$config['base_url'] = site_url('Car/index');
		 $config['total_rows'] =$query->num_rows();
		 $config['per_page'] = 6;
		 $config['num_links'] = 5;
		 $config['full_tag_open'] = '<ul class="pagination justify-content-center">';
		 $config['full_tag_close'] = '</ul>';
		 $config['cur_tag_open'] = '<li class="page-item  active"><a class="page-link" href="">';
		 $config['cur_tag_close'] = '</a></li>';
		 $config['prev_tag_open'] = '<li class="page-item page-link">';
		 $config['prev_tag_close'] = '</li>';
		 $config['next_tag_open'] = '<li class="page-item page-link">';
		 $config['next_tag_close'] = '</li>';
		 $config['num_tag_open'] = '<li class="page-item page-link">';
		 $config['num_tag_close'] = '</li>';
		 $config['last_tag_open'] = '<li class="page-item page-link">';
		 $config['last_tag_close'] = '</li>';
		 $config['first_tag_open'] = '<li class="page-item  page-link">';
		 $config['first_tag_close'] = '</li>';
		 $config['next_link'] = 'Next >';
		 $config['prev_link'] = '< Prev';

		 if ($this->uri->segment(3)) {
		 $data['segment'] = $this->uri->segment(3);
		 } else {
		 $data['segment'] = 0;
		 }
		$this->pagination->initialize($config);


		if($this->input->post('car_name')){

			$query= $this->db->where('id',$this->input->post('car_name'));
		}

		if($this->input->post('car_search')){

			$query= $this->db->where('car_name',$this->input->post('car_search'));
			$query= $this->db->or_where('car_rent',$this->input->post('car_search'));
			$query= $this->db->or_where('car_detail',$this->input->post('car_search'));
		}


		$query=$this->db->limit($config['per_page'], $data['segment'])->order_by('id','desc')->get('tbl_car');

		$data['car']=$query->result_array();


		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('car',$data);
		$this->load->view('inc/footer');
	}
}
