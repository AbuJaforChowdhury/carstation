<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {


	function __construct() {

        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if($this->session->userdata('type')!='user'){
			redirect('welcome');
		}else{
		
		}


    }

	
	public function index()
	{
		$data['booking']=$this->db->select('*,tbl_booking.id as b_id')->from('tbl_booking,tbl_user,tbl_car')->where('tbl_booking.user_id=tbl_user.id')->where('tbl_car.id=tbl_booking.car_id')->where('tbl_user.id',$this->session->userdata('id'))->order_by('b_id','DESC')->get()->result_array();

		$this->load->view('user/inc/header');
		$this->load->view('user/inc/navbar');
		$this->load->view('user/inc/sidebar');
		$this->load->view('user/dashboard',$data);
		$this->load->view('user/inc/footer');
	}


	 




}
