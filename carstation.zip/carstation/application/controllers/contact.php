<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class contact extends CI_Controller {

	
	public function index()
	{



		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('message', 'Message', 'required');
	 

		if ($this->form_validation->run() == FALSE)
		{
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('contact');
		$this->load->view('inc/footer');
		}else{


				$idata['email']=$this->input->post('email');
				$idata['name']=$this->input->post('name');
				$idata['message']=$this->input->post('message');

				$this->db->insert('tbl_message',$idata);
				
			  
				$msg='<div class="alert alert-success">Message Sent</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect('contact');



		}



	}



}
