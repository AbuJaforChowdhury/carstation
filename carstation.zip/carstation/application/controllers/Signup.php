<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {

	
	public function index()
	{	


		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Password', 'required');


		if ($this->form_validation->run() == FALSE)
		{
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('admin/signup');
		$this->load->view('inc/footer');

		}else{

				$idata['email']=$this->input->post('email');
				$idata['name']=$this->input->post('name');
				$idata['password']=$this->input->post('password');
				$idata['type']='user';

				$this->db->insert('tbl_user',$idata);
				
			  
				$msg='<div class="alert alert-success">Account Created</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect('login');

					
				 
		}
	}
}
