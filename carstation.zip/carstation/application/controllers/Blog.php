<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

	
	public function index()
	{

		$data['all_post']=$this->db->limit('10')->get('tbl_post')->result_array();
			
		$this->load->library('pagination');

	 

		if($this->input->post('post_search')){

			$query= $this->db->where('post_name',$this->input->post('post_search'));
			$query= $this->db->or_where('post_detail',$this->input->post('post_search'));
		}

		$query= $this->db->get('tbl_post');

		$config['base_url'] = site_url('Blog/index');
		 $config['total_rows'] =$query->num_rows();
		 $config['per_page'] = 3;
		 $config['num_links'] = 5;
		 $config['full_tag_open'] = '<ul class="pagination justify-content-center">';
		 $config['full_tag_close'] = '</ul>';
		 $config['cur_tag_open'] = '<li class="page-item  active"><a class="page-link" href="">';
		 $config['cur_tag_close'] = '</a></li>';
		 $config['prev_tag_open'] = '<li class="page-item page-link">';
		 $config['prev_tag_close'] = '</li>';
		 $config['next_tag_open'] = '<li class="page-item page-link">';
		 $config['next_tag_close'] = '</li>';
		 $config['num_tag_open'] = '<li class="page-item page-link">';
		 $config['num_tag_close'] = '</li>';
		 $config['last_tag_open'] = '<li class="page-item page-link">';
		 $config['last_tag_close'] = '</li>';
		 $config['first_tag_open'] = '<li class="page-item  page-link">';
		 $config['first_tag_close'] = '</li>';
		 $config['next_link'] = 'Next >';
		 $config['prev_link'] = '< Prev';

		 if ($this->uri->segment(3)) {
		 $data['segment'] = $this->uri->segment(3);
		 } else {
		 $data['segment'] = 0;
		 }
		$this->pagination->initialize($config);


		 

		if($this->input->post('post_search')){

			$query= $this->db->where('post_name',$this->input->post('post_search'));
			$query= $this->db->or_where('post_detail',$this->input->post('post_search'));
		}


		$query=$this->db->limit($config['per_page'], $data['segment'])->order_by('id','desc')->get('tbl_post');

		$data['post']=$query->result_array();


		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('blog',$data);
		$this->load->view('inc/footer');

 
	}


		public function detail($id)
	{

		$data['all_post']=$this->db->limit('10')->get('tbl_post')->result_array();
			
		 

		
		$data['post']=$query=$this->db->where('id',$id)->get('tbl_post')->result_array();



		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('detail',$data);
		$this->load->view('inc/footer');

 
	}
}
