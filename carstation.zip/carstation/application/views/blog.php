
  <section class="inner-page-banner bg_img overlay-3" data-background="<?=base_url()?>assets/images/inner-page-bg.jpg">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="page-title">Blog</h2>
          <ol class="page-list">
            <li><a href="<?=base_url()?>welcome"><i class="fa fa-home"></i> Home</a></li>
            <li>Reecent post</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-apge-banner end -->

  <!-- blog-section start -->
  <section class="blog-section pt-120 pb-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          

            <?php foreach ($post as $row) {  ?>

              <div class="post-item post-item--list">

             
          
            <div class="post-item-header">
              <a href="#0" class="post-date"><?=date('d',$row['post_date'])?><br><?=date('M',$row['post_date'])?></a>
              <h3 class="post-title"><a href="#0"><?=$row['post_name']?></a></h3>
            </div>
            <div class="thumb">
              <img src="<?=base_url()?>image/<?=$row['post_photo']?>" alt="image">
            </div>
            <ul class="post-meta">
              <li><a href="#0"><i class="fa fa-user"></i>Admin</a></li>
              <li><a href="#0"><i class="fa fa-tag"></i>Blog</a></li>
              <li><a href="#0"><i class="fa fa-book"></i><?=date('Y-m-d',$row['post_date'])?></a></li>
            </ul>
            <div class="content">
              <p><?=substr($row['post_detail'],0,200)?></p>
              
              <a href="<?=base_url()?>Blog/detail/<?=$row['id']?>" class="blog-btn">read more<i class="fa fa-chevron-right"></i></a>
            </div>
          </div>
		  <!-- post-item end -->

           <?php  } ?>
         
          <nav class="d-pagination mt-50" aria-label="Page navigation example">
            <ul class="pagination justify-content-start">
            <?php echo $this->pagination->create_links(); ?>
          </nav>
        </div>
        <div class="col-lg-4">
          <aside class="sidebar">

            <div class="widget widget-all-cars">
              <h4 class="widget-title">search in here</h4>
              <div class="widget-body">
                <form method="post" action="" class="widget-search-form">
                  <input type="search" name="post_search" id="widget-search" placeholder="Search Keyword">
                  <button class="widget-search-btn"><i class="fa fa-search"></i></button>
                </form>
              </div>
            </div><!-- widget end -->

            
    
     
            <div class="widget widget-archive">
              <h4 class="widget-title">Latest Post</h4>
              <div class="widget-body">
                <ul class="archive-list">
                  <?php if($all_post){ 

                    foreach ($all_post as $row) {  ?>
                      
                    
                  
                  <li><span><a href="<?=base_url()?>Blog/detail/<?=$row['id']?>"><?=$row['post_name']?></span></a></li>
                   
                 <?php } } ?>
                </ul>
              </div>
            </div><!-- widget end -->
            
          </aside>
        </div>
      </div>
    </div>
  </section>
  <!-- blog-section end -->

  