

  <!-- banner-section start  -->
  <section class="banner-section banner-section--style2 bg_img" data-background="<?=base_url()?>assets/images/banner.jpg">
    <div class="banner-el-img"><img src="<?=base_url()?>assets/images/elements/banner-man.png" alt="image"></div>
    <div class="container" id="booking">
      <div class="row align-items-center">
        <div class="col-lg-5">
          <div class="car-search-area mt-0">
            <h3 class="title">Search for Your Car</h3>
            <form method="post" action=""class="car-search-form">
               <?=$this->session->flashdata('message')?>
              <div class="row">
                <div class="col-xl-12 form-group">
                  <select name="car_id">
                          <option value="">---Select Car---</option>
                        <?php foreach ($all_carlist as $row) { ?>
                           
                       
                        <option <?php if(set_value('car_id')==$row['id']){ echo 'selected'; } ?> value="<?=$row['id']?>"><?=$row['car_name']?></option>
                         <?php  } ?>
                       
                      </select>
                </div>
                <div class="error"><?=form_error('car_id')?></div>
              </div>
              <div class="row">
                <div class="form-group col-xl-6">
                  <i class="fa fa-map-marker"></i>
                  <input class="form-control has-icon" type="text" name="pickup" value="<?=set_value('pickup')?>" placeholder="Pickup Location">
                  <div class="error"><?=form_error('pickup')?></div>
                </div>
                <div class="form-group col-xl-6">
                  <i class="fa fa-map-marker"></i>
                  <input class="form-control has-icon" type="text" name="drop_off"  value="<?=set_value('drop_off')?>"  placeholder="Drop Off Location">
                  <div class="error"><?=form_error('drop_off')?></div>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-xl-6">
                  <i class="fa fa-calendar"></i>
                  <input type='text' class='form-control has-icon datepicker-here' value="<?=set_value('pickup_date')?>"  name="pickup_date" data-language='en' placeholder="Pickup Date">
                  <div class="error"><?=form_error('pickup_date')?></div>
                </div>
                <div class="form-group col-xl-6">
                  <i class="fa fa-clock-o"></i>
                  <input type="text"   class="form-control has-icon timepicker" value="<?=set_value('pickup_time')?>"  name="pickup_time" placeholder="Pickup Time">
                  <div class="error"><?=form_error('pickup_time')?></div>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-xl-6">
                  <i class="fa fa-calendar"></i>
                  <input type='text' class='form-control has-icon datepicker-here'  value="<?=set_value('drop_off_date')?>"  name="drop_off_date" data-language='en' placeholder="Drop Off Date">
                  <div class="error"><?=form_error('drop_off_date')?></div>
                </div>
                <div class="form-group col-xl-6">
                  <i class="fa fa-clock-o"></i>
                  <input type="text"   class="form-control has-icon timepicker" value="<?=set_value('drop_off_time')?>"  name="drop_off_time" placeholder="Drop Off Time">
                  <div class="error"><?=form_error('drop_off_time')?></div>
                </div>
              </div>
              <button type="submit" class="cmn-btn btn-radius">Reservation</button>
            </form>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="banner-content">
            <h1 class="title">find your own car</h1>
            <p>Whether it's sharing a recipe, getting involved in local activities, looking for caregiving help or getting information on social security, CARSTATION provides you with a wealth of opportunities to save money, play, learn and volunteer. Your membership includes carefully selected products and services.</p>
            <a href="<?=base_url()?>Car" class="cmn-btn">see all vehicles</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- banner-section end  -->

  <!-- about-section start -->
  <section class="about-section pt-120 pb-120">
    <div class="element text-center"><img src="<?=base_url()?>assets/images/elements/car2.png" alt="image"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="block-area">
            <div class="block-header">
              <h2 class="title">We are Best Car Rental Company to Find Car</h2>
              <p>we are providing our services with a reputed institute over the city.To be honest,we believe in honesty,promisses,and our quality of services.</p>
            </div>
            <div class="block-body">
              <ul class="cmn-list">
                <li>Quality services</li>
                <li>experined Drivers</li>
                <li>Comfortable Vehicles</li>
                <li>reputed institute</li>
                <li>popularity on services</li>
                <li>time sense</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- about-section end -->

  <!-- counter-section start -->
  <div class="counter-section bg_img overlay-main" data-background="<?=base_url()?>assets/images/bg1.jpg">
    <div class="container">
      <div class="row mb-none-30">
        <div class="col-lg-3 col-sm-6">
          <div class="counter-item counter-item--style2">
            <div class="icon">
              <i class="fa fa-car"></i>
            </div>
            <div class="content">
              <span class="counter">100</span>
              <span class="title">total car</span>
            </div>
          </div>
        </div><!-- counter-item end -->
        <div class="col-lg-3 col-sm-6">
          <div class="counter-item counter-item--style2">
            <div class="icon">
              <i class="fa fa-smile-o"></i>
            </div>
            <div class="content">
              <span class="counter">1500</span>
              <span class="title">happy customer</span>
            </div>
          </div>
        </div><!-- counter-item end -->
        <div class="col-lg-3 col-sm-6">
          <div class="counter-item counter-item--style2">
            <div class="icon">
              <i class="fa fa-truck"></i>
            </div>
            <div class="content">
              <span class="counter">1400k</span>
              <span class="title">travel time</span>
            </div>
          </div>
        </div><!-- counter-item end -->
        <div class="col-lg-3 col-sm-6">
          <div class="counter-item counter-item--style2">
            <div class="icon">
              <i class="fa fa-puzzle-piece"></i>
            </div>
            <div class="content">
              <span class="counter">700</span>
              <span class="title">solution</span>
            </div>
          </div>
        </div><!-- counter-item end -->
      </div>
    </div>
  </div>
  <!-- counter-section end -->

  <!-- choose-car-section start -->
  <section class="choose-car-section pt-120 pb-120">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="section-header text-center">
            <h2 class="section-title">our awsome car in here</h2>
            <p> we gatherd best collection of the vehicles based on presnt time.</p>
          </div>
        </div>
      </div>
      <div class="row mb-none-30">
        <div class="col-lg-6">
          <div class="car-item car-item--style2">
            <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/cars/8.jpg"></div>
            <div class="car-item-body">
              <div class="content">
                <h4 class="title">forester subar</h4>
                <span class="price">start form 1500 per day</span>
                <p>comfortable to travel and for long journy too.</p>
                <a href="#booking" class="cmn-btn">rent car</a>
              </div>
              <div class="car-item-meta">
                <ul class="details-list">
                  <li><i class="fa fa-car"></i>model 2014ib</li>
                  <li><i class="fa fa-tachometer"></i>32000 KM</li>
                </ul>
              </div>
            </div>
          </div><!-- car-item end -->
        </div><!-- car-item end -->
        <div class="col-lg-6">
          <div class="car-item car-item--style2">
            <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/cars/v2.jpg"></div>
            <div class="car-item-body">
              <div class="content">
                <h4 class="title">mistubisshi</h4>
                <span class="price">start form 1500 per day</span>
                <p>comfortable to travel and for long journy too.</p>
               <a href="#booking"class="cmn-btn">rent car</a>
              </div>
              <div class="car-item-meta">
                <ul class="details-list">
                  <li><i class="fa fa-car"></i>model 2014ib</li>
                  <li><i class="fa fa-tachometer"></i>32000 KM</li>
                </ul>
              </div>
            </div>
          </div><!-- car-item end -->
        </div><!-- car-item end -->
        <div class="col-lg-6">
          <div class="car-item car-item--style2">
            <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/cars/v3.jpg"></div>
            <div class="car-item-body">
              <div class="content">
                <h4 class="title">mirage range</h4>
                 <span class="price">start form 1500 per day</span>
                <p>comfortable to travel and for long journy too.</p>
               <a href="#booking" class="cmn-btn">rent car</a>
              </div>
              <div class="car-item-meta">
                <ul class="details-list">
                  <li><i class="fa fa-car"></i>model 2014ib</li>
                  <li><i class="fa fa-tachometer"></i>32000 KM</li>
                </ul>
              </div>
            </div>
          </div><!-- car-item end -->
        </div><!-- car-item end -->
        <div class="col-lg-6">
          <div class="car-item car-item--style2">
            <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/cars/v4.jpg"></div>
            <div class="car-item-body">
              <div class="content">
                <h4 class="title">pajero range</h4>
                 <span class="price">start form 1500 per day</span>
               <p>comfortable to travel and for long journy too.</p>
               <a href="#booking" class="cmn-btn">rent car</a>
              </div>
              <div class="car-item-meta">
                <ul class="details-list">
                  <li><i class="fa fa-car"></i>model 2014ib</li>
                  <li><i class="fa fa-tachometer"></i>32000 KM</li>
                </ul>
              </div>
            </div>
          </div><!-- car-item end -->
        </div><!-- car-item end -->
      </div>
    </div>
  </section>
  <!-- choose-car-section end -->

  

  <!-- choose-us-section start -->
  <section class="choose-us-section pt-120 pb-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="choose-us-content">
            <h2 class="title title--border text-capitalize">Why choose our company</h2>
            <div class="choose-us-area">
              <div class="choose-us-item">
                <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/choose-us/1.jpg"></div>
                <div class="content">
                  <h4 class="title">expert drivers</h4>
                  <p>Experince drivers are available at our institute.</p>
                </div>
              </div><!-- choose-us-item end -->
              <div class="choose-us-item">
                <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/cars/7.jpg"></div>
                <div class="content">
                  <h4 class="title">fast services</h4>
                  <p>We try to utilize the given time of clients.</p>
                </div>
              </div><!-- choose-us-item end -->
              <div class="choose-us-item">
                <div class="thumb bg_img" data-background="<?=base_url()?>assets/images/choose-us/3.jpg"></div>
                <div class="content">
                  <h4 class="title">customer support</h4>
                  <p>we provide the services to keep happy and cool the customers.</p>
                </div>
              </div><!-- choose-us-item end -->
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="request-quote-area">
            <div class="request-quote-header">
              <h3 class="title">request for quote</h3>
            </div>
            <div class="request-quote-body">
                <?=$this->session->flashdata('message')?>
              <form method="post" action="<?=base_url()?>Contact" class="request-quote-form">
                <div class="form-group">
                  <input type="text" name="name" id="name" placeholder="Your Name">
                </div>
                <div class="error"><br><?=form_error('name')?></div>
                <div class="form-group">
                  <input type="email" name="email" id="email" placeholder="Email Address">
                </div>
                 <div class="error"><br><?=form_error('email')?></div>
                
                <div class="form-group">
                  <textarea name="message" id="message" placeholder="Write Message"></textarea>
                </div>
                 <div class="error"><br><?=form_error('message')?></div>
                <button type="submit" class="cmn-btn">Send Message</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- choose-us-section end -->





  <!-- brand-section start -->
  <div class="brand-section pb-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="brand-slider owl-carousel">
            <div class="brand-item">
              <div class="brand-item--inner">
                <img src="<?=base_url()?>assets/images/brand-logo/5.png" alt="image">
              </div>
            </div><!-- brand-item end -->
            <div class="brand-item">
              <div class="brand-item--inner">
                <img src="<?=base_url()?>assets/images/brand-logo/6.png" alt="image">
              </div>
            </div><!-- brand-item end -->
            <div class="brand-item">
              <div class="brand-item--inner">
                <img src="<?=base_url()?>assets/images/brand-logo/7.png" alt="image">
              </div>
            </div><!-- brand-item end -->
            <div class="brand-item">
              <div class="brand-item--inner">
                <img src="<?=base_url()?>assets/images/brand-logo/5.png" alt="image">
              </div>
            </div><!-- brand-item end -->
            <div class="brand-item">
              <div class="brand-item--inner">
                <img src="<?=base_url()?>assets/images/brand-logo/6.png" alt="image">
              </div>
            </div><!-- brand-item end -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- brand-section end -->
