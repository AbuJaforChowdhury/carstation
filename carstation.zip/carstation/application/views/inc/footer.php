
  <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top pt-120 pb-120">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-8">
            <div class="footer-widget widget-about">
              <div class="widget-about-content">
                <a href="<?=base_url()?>welcome" class="footer-logo"><img src="<?=base_url()?>assets/images/carlogo.png" alt="logo"></a>
                <p>we hope we can give the best service for the clients happiness and be confidencial on institute. </p>
                <ul class="social-links">
                  <li><a href="#0"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#0"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#0"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget widget-menu">
              <h4 class="widget-title">our cars</h4>
              <ul>
                <li><a href="<?=base_url()?>Car">mistubishi lancer</a></li>
                <li><a href="<?=base_url()?>Car">forester subar</a></li>
                <li><a href="<?=base_url()?>Car">mirage ange</a></li>
                <li><a href="<?=base_url()?>Car">pajero range</a></li>
                <li><a href="<?=base_url()?>Car">subaru liberty</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget widget-menu">
              <h4 class="widget-title">useful link</h4>
              <ul>
                <li><a href="<?=base_url()?>About">about</a></li>
                <li><a href="<?=base_url()?>">reservation</a></li>
                <li><a href="<?=base_url()?>">faq</a></li>
                <li><a href="<?=base_url()?>recent_post">blog</a></li>
                <li><a href="<?=base_url()?>Car">car list</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-sm-8">
            <div class="footer-widget widget-address">
              <h4 class="widget-title">contact with us</h4>
              <ul>
                <li>
                  <i class="fa fa-map-marker"></i>
                  <span>carstation,Sylhet</span>
                </li>
                <li>
                  <i class="fa fa-envelope"></i>
                  <span>abujaforchowdhury7@gmail.com</span>
               </li>
                <li>
                  <i class="fa fa-phone-square"></i>
                  <span>+8801796 422 214</span>
               </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
   
  </footer>
  <!-- footer-section end -->
  
  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-rocket"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->

  <!-- jquery js link -->
  <script src="<?=base_url()?>assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js link -->
  <script src="<?=base_url()?>assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js link -->
  <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
  <!-- lightcase js link -->
  <script src="<?=base_url()?>assets/js/lightcase.js"></script>
  <!-- wow js link -->
  <script src="<?=base_url()?>assets/js/wow.min.js"></script>
  <!-- nice select js link -->
  <script src="<?=base_url()?>assets/js/jquery.nice-select.min.js"></script>
  <!-- datepicker js link -->
  <script src="<?=base_url()?>assets/js/datepicker.min.js"></script>
  <script src="<?=base_url()?>assets/js/datepicker.en.js"></script>
  <!-- wickedpicker js link -->
  <script src="<?=base_url()?>assets/js/wickedpicker.min.js"></script>
  <!-- owl carousel js link -->
  <script src="<?=base_url()?>assets/js/owl.carousel.min.js"></script>
  <!-- jquery ui js link -->
  <script src="<?=base_url()?>assets/js/jquery-ui.min.js"></script>
  <!-- main js link -->
  <script src="<?=base_url()?>assets/js/main.js"></script>

 <style type="text/css">

  .error{
  font-size:12px;
  color:red!important;
  }
  </style>
</body>

</html>