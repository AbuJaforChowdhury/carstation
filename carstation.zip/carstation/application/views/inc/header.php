<!DOCTYPE html>
<html lang="en">


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Renten - Car Rental Service HTML Template</title>
  <!-- site favicon -->
  <link rel="shortcut icon" type="image/png" href="<?=base_url()?>assets/images/favicon.jpg"/>
  <!-- fontawesome css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/fontawesome.min.css">
  <!-- bootstrap css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap.min.css">
  <!-- lightcase css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/lightcase.css">
  <!-- animate css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/animate.css">
  <!-- nice select css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/nice-select.css">
  <!-- datepicker css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/datepicker.min.css">
  <!-- wickedpicker css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/wickedpicker.min.css">
  <!-- jquery ui css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/jquery-ui.min.css">
  <!-- owl carousel css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/owl.carousel.min.css">
  <!-- main style css link -->
  <link rel="stylesheet" href="<?=base_url()?>assets/css/main.css">
</head>
<body>
