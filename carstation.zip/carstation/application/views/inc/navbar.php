
  <!--  header-section start  -->
  <header class="header-section header-section--style2">
    <div class="header-bottom">
      <div class="container">
        <nav class="navbar navbar-expand-lg p-0">
          <a class="site-logo site-title" href="<?=base_url()?>welcome"><img src="<?=base_url()?>assets/images/carlogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="menu-toggle"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav main-menu m-auto">
              <li ><a href="<?=base_url()?>welcome">Home</a> </li>
              <li><a href="<?=base_url()?>about">About</a></li>
              <li><a href="<?=base_url()?>Blog">Blog</a></li>
			          <li><a href="<?=base_url()?>car">Car</a></li>
              <li><a href="<?=base_url()?>contact">contact us</a></li>
              <?php if($this->session->userdata('type')=='admin') { ?>

              <li><a href="<?=base_url()?>admin">Dashboard</a></li>
             

             <?php }else if($this->session->userdata('type')=='user') {  ?>

             <li><a href="<?=base_url()?>user">Dashboard</a></li>
             
             <?php }else{  ?>

              <li><a href="<?=base_url()?>signup">Register</a></li>
             <li><a href="<?=base_url()?>login">Login</a></li>

             <?php } ?>
             
            </ul>
          </div>
        </nav>
      </div>
    </div><!-- header-bottom end -->
  </header>
  <!--  header-section end  -->