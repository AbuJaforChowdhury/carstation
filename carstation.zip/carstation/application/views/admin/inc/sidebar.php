
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?=base_url()?>Admin">
        <div class="sidebar-brand-icon">
          <img src="<?=base_url()?>assets/admin-asset/img/logo/logo2.png">
        </div>
        <div class="sidebar-brand-text mx-3">Car Station</div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?=base_url()?>Admin">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
       
      

	  <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fa fa-car"></i>
          <span>Car</span>
        </a>
        <div id="collapseTable" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
            <a class="collapse-item" href="<?=base_url()?>Admin/add-car">Add Car</a>
            <a class="collapse-item" href="<?=base_url()?>Admin/view-car">View Car</a>
            
          </div>
        </div>
      </li>
       <li class="nav-item">

      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable4" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fa fa-blog"></i>
          <span>Post</span>
        </a>
        <div id="collapseTable4" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
            <a class="collapse-item" href="<?=base_url()?>Admin/add-post">Add Post</a>
            <a class="collapse-item" href="<?=base_url()?>Admin/view-post">View Post</a>
            
          </div>
        </div>
      </li>


      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable2" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fa fa-user"></i>
          <span>User</span>
        </a>
        <div id="collapseTable2" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
             <a class="collapse-item" href="<?=base_url()?>Admin/view-user">View User</a>
            
          </div>
        </div>
      </li>
        


        
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable1" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fa fa-envelope"></i>
          <span>Message</span>
        </a>
        <div id="collapseTable1" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
             <a class="collapse-item" href="<?=base_url()?>Admin/view-message">View message</a>
            
          </div>
        </div>
      </li>



       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable3" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fa fa-book"></i>
          <span>Booking</span>
        </a>
        <div id="collapseTable3" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
             <a class="collapse-item" href="<?=base_url()?>Admin/view-booking">View Booking</a>
            
          </div>
        </div>
      </li>
        
		
		
	
      <hr class="sidebar-divider">
      <div class="version" id="version-ruangadmin"></div>
    </ul>
    <!-- Sidebar -->
   