  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Post</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Edit Post</li>
            </ol>
          </div>

          <div class="row mb-3">


            <div class="col-md-6">
                
                   <form action="" method="post" enctype="multipart/form-data" >

                        <?php echo $this->session->flashdata('message'); ?>

                     

                        <div class="form-group"> 
                            <input type="text" class="form-control input-lg" value="<?php if(set_value('post_name')){ echo set_value('post_name'); } else{ echo $post[0]['post_name']; }?>" placeholder="Post Title" name="post_name">

                            <div class="error"><?=form_error('post_name')?></div>

                        </div>


                       


                        <div class="form-group"> 
                            <input type="date" class="form-control input-lg" value="<?php if(set_value('post_date')){ echo set_value('post_date'); } else{ echo date('Y-m-d',$post[0]['post_date']); }?>" placeholder="Post Date" name="post_date">

                            <div class="error"><?=form_error('post_date')?></div>

                        </div>


                         


                        <div class="form-group"> 
                           
                             <textarea name="post_detail" class="form-control input-lg" ><?php if(set_value('post_detail')){ echo set_value('post_detail'); } else{ echo $post[0]['post_detail']; }?></textarea>

                            <div class="error"><?=form_error('post_detail')?></div>

                        </div>
 


                        <div class="form-group"> 
            
                           <input type="file" name="post_photo">

                        </div>


 
                      
                         <div class="form-group"> 
            
                            <button type="submit" class="btn btn-primary">Edit post</button>

                        </div>

                        </form>


            </div>
           
        
          </div>
          <!--Row-->

          
