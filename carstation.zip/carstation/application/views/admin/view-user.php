  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">user</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">View user</li>
            </ol>
          </div>

          <div class="row mb-3">
           
            <!-- Invoice Example -->
            <div class="col-xl-12 col-lg-12 mb-4">
              <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                   
                </div>
                <div class="table-responsive">

                   <?php if ($user){ ?>
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($user as $user) {  ?>
                         
                    
                      <tr>
                         <td><?=$user['name']?></td>
                        <td><?=$user['email']?></td>
                     
                        <td>
                           <a href="<?=base_url()?>Admin/delete-user/<?=$user['id']?>" class="btn btn-sm btn-danger">Delete</a>
                           

                        </td>
                      </tr>

                       <?php  } ?>
                    
                    </tbody>
                  </table>

                <?php  } ?>
                </div>
                <div class="card-footer"></div>
              </div>
            </div>
            <!-- Message From Customer-->
            
          </div>
          <!--Row-->

          

        