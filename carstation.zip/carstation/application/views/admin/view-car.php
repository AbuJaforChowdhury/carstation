  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Car</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Car</li>
            </ol>
          </div>

          <div class="row mb-3">
           
            <!-- Invoice Example -->
            <div class="col-xl-12 col-lg-12 mb-4">
              <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                   
                </div>
                <div class="table-responsive">

                   <?php if ($car){ ?>
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>Car Image</th>
                        <th>Car Name</th>
                        <th>Car Rent</th>
                        <th>Car Detail</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($car as $car) {  ?>
                         
                    
                      <tr>
                        <td><img src="<?=base_url()?>image/<?=$car['car_photo']?>" width="150px" height="100px;" alt=""></td>
                        <td><?=$car['car_name']?></td>
                        <td><?=$car['car_rent']?></td>
                        <td><?=$car['car_detail']?></td>
                        <td>
                          <a href="<?=base_url()?>Admin/edit-car/<?=$car['id']?>" class="btn btn-sm btn-primary">Edit</a>
                          <a href="<?=base_url()?>Admin/delete-car/<?=$car['id']?>" class="btn btn-sm btn-danger">Delete</a>

                        </td>
                      </tr>

                       <?php  } ?>
                    
                    </tbody>
                  </table>

                <?php  } ?>
                </div>
                <div class="card-footer"></div>
              </div>
            </div>
            <!-- Message From Customer-->
            
          </div>
          <!--Row-->

          

        