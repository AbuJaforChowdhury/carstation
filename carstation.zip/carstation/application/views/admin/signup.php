<section class="banner-section banner-section--style2 bg_img" data-background="<?=base_url()?>assets/images/banner.jpg">
 </section>
  <!-- Register Content -->
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card shadow-sm my-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-6 offset-3">
                <div class="login-form">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Register</h1>
                  </div>
                <form action="" method="post">

                <?=$this->session->flashdata('message')?>
		
		 <div class="form-group">
			<label for="exampleInputEmail1">Name</label>
			<input type="text" name="name" class="form-control" value="<?=set_value('name')?>" placeholder="Enter Name"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('name')?><br></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Email</label>
			<input type="text" name="email" class="form-control" value="<?=set_value('email')?>" placeholder="Enter email"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('email')?><br></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Password</label>
			<input type="password"  name="password" class="form-control" value="<?=set_value('password')?>" placeholder="Enter password"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('password')?><br></div>
			
			
		  <div class="form-group">
			<label for="exampleInputEmail1">Confirm Password</label>
			<input type="password"  name="confirm_password" class="form-control" value="<?=set_value('confirm_password')?>" placeholder="Enter confirm assword"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('confirm_password')?><br></div>
			



		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
                  <hr>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  