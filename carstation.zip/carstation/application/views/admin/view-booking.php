  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Booking</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Booking</li>
            </ol>
          </div>

          <div class="row mb-3">
           
            <!-- Invoice Example -->
            <div class="col-xl-12 col-lg-12 mb-4">
              <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                   
                </div>
                <div class="table-responsive">

                   <?php if ($booking){ ?>
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>Car Photo</th>
                        <th>Car name</th>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Pick Up</th>
                        <th>Drop Off</th>
                        <th>Pick Up Date & Time</th>
                        <th>Drop Off Date & Time</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($booking as $booking) {  ?>
                         
                    
                      <tr>
                         <td><img src="<?=base_url()?>image/<?=$booking['car_photo']?>" width="70px" height="50px" alt=""></td>
                         <td><?=$booking['car_name']?></td>
                        <td><?=$booking['name']?></td>
                        <td><?=$booking['email']?></td>
                        <td><?=$booking['pickup']?></td>
                        <td><?=$booking['drop_off']?></td>
                        <td><?=$booking['pickup_date']?> <br> <?=$booking['pickup_time']?></td>
                        
                        <td><?=$booking['drop_off_date']?> <br> <?=$booking['drop_off_time']?></td>
                    
                        <td>
                           <a href="<?=base_url()?>Admin/delete-booking/<?=$booking['b_id']?>" class="btn btn-sm btn-danger">Delete</a>
                           

                        </td>
                      </tr>

                       <?php  } ?>
                    
                    </tbody>
                  </table>

                <?php  } ?>
                </div>
                <div class="card-footer"></div>
              </div>
            </div>
            <!-- Message From Customer-->
            
          </div>
          <!--Row-->

          

        