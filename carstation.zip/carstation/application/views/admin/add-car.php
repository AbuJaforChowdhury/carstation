  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Car</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Add Car</li>
            </ol>
          </div>

          <div class="row mb-3">


            <div class="col-md-6">
                
                   <form action="" method="post" enctype="multipart/form-data" >

                        <?php echo $this->session->flashdata('message'); ?>


                         <div class="form-group"> 
                            <input type="text" class="form-control input-lg" value="<?=set_value('car_name')?>" placeholder="Car Name" name="car_name">

                            <div class="error"><?=form_error('car_name')?></div>

                        </div>


                        <div class="form-group"> 
                            <input type="text" class="form-control input-lg" value="<?=set_value('car_rent')?>" placeholder="Car Rent" name="car_rent">

                            <div class="error"><?=form_error('car_rent')?></div>

                        </div>


                         


                        <div class="form-group"> 
                           
                             <textarea name="car_detail" class="form-control input-lg" ><?=set_value('car_detail')?></textarea>

                            <div class="error"><?=form_error('car_detail')?></div>

                        </div>
 


                        <div class="form-group"> 
            
                           <input type="file" name="car_photo">

                        </div>


 
                      
                         <div class="form-group"> 
            
                            <button type="submit" class="btn btn-primary">Add car</button>

                        </div>

                        </form>


            </div>
           
        
          </div>
          <!--Row-->

          
