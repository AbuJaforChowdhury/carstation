  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
         

          <div class="row mb-3">
           
            <!-- Invoice Example -->
            <div class="col-xl-12 col-lg-12 mb-4">
              <div class="postd">
                <div class="postd-header py-3 d-flex flex-row align-items-center justify-content-between">
                   
                </div>
                <div class="table-responsive">

                   <?php if ($post){ ?>
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>Post Image</th>
                        <th>Post Title</th>
                        <th>Post Date</th>
                        <th>Post Detail</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($post as $post) {  ?>
                         
                    
                      <tr>
                        <td><img src="<?=base_url()?>image/<?=$post['post_photo']?>" width="150px" height="100px;" alt=""></td>
                        <td><?=$post['post_name']?></td>
                        <td><?=date('Y-m-d',$post['post_date'])?></td>
                        <td><?=$post['post_detail']?></td>
                        <td>
                          <a href="<?=base_url()?>Admin/edit-post/<?=$post['id']?>" class="btn btn-sm btn-primary">Edit</a>
                          <a href="<?=base_url()?>Admin/delete-post/<?=$post['id']?>" class="btn btn-sm btn-danger">Delete</a>

                        </td>
                      </tr>

                       <?php  } ?>
                    
                    </tbody>
                  </table>

                <?php  } ?>
                </div>
                <div class="postd-footer"></div>
              </div>
            </div>
            <!-- Message From Customer-->
            
          </div>
          <!--Row-->

          

        