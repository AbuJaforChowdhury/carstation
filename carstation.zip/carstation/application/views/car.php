

  

  <!-- inner-apge-banner start -->
  <section class="inner-page-banner bg_img overlay-3" data-background="<?=base_url()?>assets/images/inner-page-bg.jpg">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="page-title">Car</h2>
          <ol class="page-list">
            <li><a href="<?=base_url()?>welcome"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="#0">Car list</a></li>
            <li>Car</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-apge-banner end -->

  <!-- car-search-section start -->
  <section class="car-search-section pt-120 pb-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="car-search-filter-area">
            <div class="car-search-filter-form-area">
              <form action="" method="post" class="car-search-filter-form">
                <div class="row justify-content-between">
                  <div class="col-lg-4 col-md-5 col-sm-6">
                    <div class="cart-sort-field">
                      <span class="caption">Sort by : </span>

                      <select name="car_name">
                          <option>---Car Type---</option>
                        <?php foreach ($all_carlist as $row) { ?>
                           
                       
                        <option value="<?=$row['id']?>"><?=$row['car_name']?></option>
                         <?php  } ?>
                       
                      </select>
                    </div>
                  </div>
                  <div class="col-lg-7 col-md-7 col-sm-6 d-flex">
                    <input type="text" name="car_search" id="car_search" placeholder="Search what you want">
                    <button class="search-submit-btn">Search</button>
                  </div>
                </div>
              </form>
            </div>
            <div class="view-style-toggle-area">
              <button class="view-btn list-btn"><i class="fa fa-bars"></i></button>
              <button class="view-btn grid-btn active"><i class="fa fa-th-large"></i></button>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-70">
        <div class="col-lg-8">
          <div class="car-search-result-area grid--view row mb-none-30">

              <?php foreach ($car as $row) { ?>
            <div class="col-md-6 col-12">
              <div class="car-item">
                <div class="thumb bg_img" data-background="<?=base_url()?>image/<?=$row['car_photo']?>"></div>
                <div class="car-item-body">
                  <div class="content">
                    <h4 class="title"><?=$row['car_name']?></h4>
                    <span class="price">start form $<?=$row['car_rent']?> per day</span>
                    <p><?=$row['car_detail']?></p>
                    <a href="<?=base_url()?>" class="cmn-btn">rent car</a>
                  </div>
                  <div class="car-item-meta">
                    <ul class="details-list">
                      <li><i class="fa fa-car"></i>New Model</li>
                      <li><i class="fa fa-tachometer"></i>Super fast</li>
                      <li><i class="fa fa-sliders"></i>Auto</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div><!-- car-item end -->
          <?php } ?>
            
          </div>
          <nav class="d-pagination" aria-label="Page navigation example">
             

             <?=$this->pagination->create_links()?>
          </nav>
        </div>
        <div class="col-lg-4">
          <aside class="sidebar">
            <div class="widget widget-reservation">
              <h4 class="widget-title">reservation</h4>
              <div class="widget-body">
                 <form method="post" action="<?=base_url()?>"class="car-search-form">
               <?=$this->session->flashdata('message')?>
              <div class="row">
                <div class="col-xl-12 form-group">
                  <select name="car_id">
                          <option value="">---Select Car---</option>
                        <?php foreach ($all_carlist as $row) { ?>
                           
                       
                        <option <?php if(set_value('car_id')==$row['id']){ echo 'selected'; } ?> value="<?=$row['id']?>"><?=$row['car_name']?></option>
                         <?php  } ?>
                       
                      </select>
                </div>
                <div class="error"><?=form_error('car_id')?></div>
              </div>
              <div class="row">
                <div class="form-group col-xl-12">
                  <i class="fa fa-map-marker"></i>
                  <input class="form-control has-icon" type="text" name="pickup" value="<?=set_value('pickup')?>" placeholder="Pickup Location">
                  <div class="error"><?=form_error('pickup')?></div>
                </div>
                <div class="form-group col-xl-12">
                  <i class="fa fa-map-marker"></i>
                  <input class="form-control has-icon" type="text" name="drop_off"  value="<?=set_value('drop_off')?>"  placeholder="Drop Off Location">
                  <div class="error"><?=form_error('drop_off')?></div>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-xl-12">
                  <i class="fa fa-calendar"></i>
                  <input type='text' class='form-control has-icon datepicker-here' value="<?=set_value('pickup_date')?>"  name="pickup_date" data-language='en' placeholder="Pickup Date">
                  <div class="error"><?=form_error('pickup_date')?></div>
                </div>
                <div class="form-group col-xl-12">
                  <i class="fa fa-clock-o"></i>
                  <input type="text"   class="form-control has-icon timepicker" value="<?=set_value('pickup_time')?>"  name="pickup_time" placeholder="Pickup Time">
                  <div class="error"><?=form_error('pickup_time')?></div>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-xl-12">
                  <i class="fa fa-calendar"></i>
                  <input type='text' class='form-control has-icon datepicker-here'  value="<?=set_value('drop_off_date')?>"  name="drop_off_date" data-language='en' placeholder="Drop Off Date">
                  <div class="error"><?=form_error('drop_off_date')?></div>
                </div>
                <div class="form-group col-xl-12">
                  <i class="fa fa-clock-o"></i>
                  <input type="text"   class="form-control has-icon timepicker" value="<?=set_value('drop_off_time')?>"  name="drop_off_time" placeholder="Drop Off Time">
                  <div class="error"><?=form_error('drop_off_time')?></div>
                </div>
              </div>
              <button type="submit" class="cmn-btn btn-radius">Reservation</button>
            </form>
              </div>
            </div><!-- widget end -->
 
          </aside>
        </div>
      </div>
    </div>
  </section>
  <!-- car-search-section end -->

 